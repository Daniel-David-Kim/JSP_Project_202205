function intro() {
	location.href="./intro.jsp";
}