// 여기서 프로젝트명은 꼭 바꾸어주어야 함!
function intro() {
	location.href="/ProtoType03/center/intro";
}